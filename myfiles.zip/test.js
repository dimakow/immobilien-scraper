let testFn = require('./app')

testFn.myHandler({}, {})
